import React from 'react'

const CancelPage = () => {
    return (
        <div>
            Paymetn Canceled
        </div>
    )
}

export default CancelPage