import React from 'react'

const SuccessPage = () => {
    return (
        <div>
            Payment Success
        </div>
    )
}

export default SuccessPage